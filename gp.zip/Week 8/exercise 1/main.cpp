//conditional and looping constructs
#include <iostream>

using namespace std;
class Calculator
{
    int c;
public:
    void add(int a,int b)
    {
        c=a+b;
        cout<<"Addition of 2 numbers is  :  "<<c;
    }
    void sub(int a,int b)
    {
        c=a-b;
        cout<<"Subtraction of 2 numbers is  : "<<c;
    }
    void multiplication(int a,int b)
    {
        c=a*b;
        cout<<"Multiplication of 2 numbers is  : "<<c;
    }
    void division(int a,int b)
    {
        c=a/b;
        cout<<"Division of 2 numbers is  : "<<c;
    }
};
int main()
{
    Calculator c;
    int a,b;
    int choice;
    cout<<"\nEnter Your choice  : ";
    cin>>choice;
    cout<<"\nEnter First Number :  ";
    cin>>a;
    cout<<"\nEnter Second Number : ";
    cin>>b;
    if (a>0 && b>0)
    {
        switch(choice)
        {
        case 1:
            c. add(a,b);
            break;
        case 2:
            c.sub(a,b);
            break;
        case 3:
            c.multiplication(a,b);
            break;
        case 4:
            c.division(a,b);
            break;
        default:
            cout<<"Invalid Choice";
        }
    }
    else
    {
        cout<<"Invalid Number";
    }
    return 0;
}
