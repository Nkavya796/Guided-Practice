//polymorphism
#include <iostream>

using namespace std;
class Chairs
{
    float price;
    float width;
    float height;

    public:
    void get()
    {
        cout<<"enter price of chairs";
        cin>>price;
        cout<<"enter widht of chairs";
        cin>>width;
        cout<<"enter height of chairs";
        cin>>height;
    }
    void print()
    {
        cout<<"price is"<<price<<endl;
        cout<<"width is"<<width<<endl;
        cout<<"height is"<<height<<endl;

    }

};
class book_shelf : public Chairs
{
    float price;
    float width;
    float height;
    public:
    void getdetails()
    {
        cout<<"enter price";
        cin>>price;
        cout<<"enter width";
        cin>>width;
        cout<<"enter height";
        cin>>height;
    }
    void printdetails()
    {
        cout<<"price is"<<price<<endl;
        cout<<"width is"<<width<<endl;
        cout<<"height is"<<height<<endl;
    }

};
int main()
{
    book_shelf b;
    b.getdetails();
    b.print();
    b.getdetails();
    b.printdetails();

return 0;
}
