#include <iostream>

using namespace std;
bool findPerfectNumber(int num);
int main()
{
    int num;
   cout<<"Enter a Number  : ";
   cin>>num;
   bool result= findPerfectNumber(num);
   if(result)
   {
     cout<<num<<" is a Perfect Number";
   }
   else
   {
       cout<<num<<" is Not a Perfect Number";
   }
    return 0;
}
bool findPerfectNumber(int number)
    {
        int sum=0;
         for(int i=1;i<=number;i++)
         {
           if(number%i == 0)
           {
              sum+=i;
           }
         }
         if(sum/2 == number)
         {
          return true;
         }else
         {
          return false;
         }
    }
