//enum
#include <iostream>

using namespace std;
enum directions {NORTH, SOUTH, EAST, WEST, NORTHEAST, SOUTHEAST, SOUTHWEST,NORTHWEST};
int main()
{
    int num;
   cout<<"Enter a Number between 0-7  : ";
   cin>>num;
   switch(num){
     case NORTH: cout<<"I am in North Direction\n";
     break;
     case SOUTH: cout<<"I am in South Direction\n";
     break;
     case EAST: cout<<"This is East Direction\n";
     break;
     case WEST: cout<<"This is West Direction\n";
     break;
     case NORTHEAST: cout<<"Now i am in NORTHEAST Direction\n";
     break;
     case SOUTHEAST: cout<<"Going to SOUTHEAST Direction\n";
     break;
     case NORTHWEST: cout<<"Finally I am in NORTHWEST Direction\n";
     break;
     case SOUTHWEST: cout<<"He is Coming from SOUTHWEST Direction\n";
     break;
     default:
        cout<<"Please Enter a Number between 0-7\n";
   }
    return 0;
}
