//inheritance
#include <iostream>
using namespace std;
class University
{
    public:
    int id;
    int age;
};

class Student : public University
{
    char student_fname[20];
    char student_lname[20];
    char course[20];

    public:
    void getDetails()
    {
        cout<<"Enter student name : ";
        cin>>student_fname;
        cout<<"Enter student last name : ";
        cin>>student_lname;
        cout<<"Enter student age : ";
        cin>>age;
        cout<<"Enter student course : ";
        cin>>course;
        cout<<"Enter student id : ";
        cin>>id;
    }

    void printDetails()
    {
        cout<<"---------Your Details are ----------------------"<<endl;
        cout<<"Student first name is : "<<student_fname<<endl;
        cout<<"Student last name : "<<student_lname<<endl;
        cout<<"Student age is : "<<age<<endl;
        cout<<"Student course is : "<<course<<endl;
        cout<<"Student id is : "<<id<<endl;
    }


};

class Employee:public University
{
    char emp_fname[20];
    char emp_lname[20];
    float salary;
    int department_time;
    char designation[20];
    public:
    void getDetails()
    {
        cout<<"Enter Employee first name : ";
        cin>>emp_fname;
        cout<<"Enter Employee last name : ";
        cin>>emp_lname;
        cout<<"Enter Employee age : ";
        cin>>age;
        cout<<"Enter salary : ";
        cin>>salary;
        cout<<"Enter department time : ";
        cin>>department_time;
        cout<<"Enter designation : ";
        cin>>designation;
        cout<<"Enter Employee id : ";
        cin>>id;
    }
    void printDetails()
    {
        cout<<"Employee first name is : "<<emp_fname<<endl;
        cout<<"Employee last name : "<<emp_lname<<endl;
        cout<<"Employee age is : "<<age<<endl;
        cout<<"Employee salary is : "<<salary<<endl;
        cout<<"Employee department_time is : "<<department_time<<endl;
        cout<<"Employee designation is : "<<designation<<endl;
        cout<<"Employee id is : "<<id;
    }
};

int main()
{

    Student s;
    Employee e;

    int choice;
    cout<<"Enter choice : ";
    cin>>choice;
    switch(choice)
    {
        case 1:
        s.getDetails();
        s.printDetails();
        break;
        case 2:
        s.getDetails();
        s.printDetails();
        break;
        default:
        cout<<"Invalid Choice";
    }


    return 0;
}
