#include<iostream>
using namespace std;
typedef struct student
{
    char name[50];
    int rollno;

    string marks;
    string cellno;
    string dob;
    string address;
};
void get_data(student s[],int n)
{
    for(int i=0;i<n;i++)
{

cout<<"enter student roll number";
    cin>>s[i].rollno;
    cout<<"enter student name";
    cin>>s[i].name;
    cout<<"enter student marks";
    cin>>s[i].marks;
    cout<<"enter student cell number";
    cin>>s[i].cellno;
    cout<<"enter student date of birth";
    cin>>s[i].dob;
    cout<<"enter student address";
    cin>>s[i].address;
}
}
void show_data(student s[],int n)
{
    for(int i=0;i<n;i++)

{

    cout<<"enter the student details"<<endl;
    cout<<"roll number"<<s[i].rollno<<endl;
    cout<<"student name"<<s[i].name<<endl;
    cout<<"student marks"<<s[i].marks<<endl;
    cout<<"cell number"<<s[i].cellno<<endl;
    cout<<"date of birth"<<s[i].dob<<endl;
    cout<<"address"<<s[i].address <<endl;

}
}
int main()
{

    student s[2];
    int choice;
    do
    {
        cout<<"MENU"<<endl;
        cout<<"1.Enter the Student  Details"<<endl;
        cout<<"2.Display the Student Details"<<endl;
        cout<<"3.Search by Student ID"<<endl;
        cout<<"4.Search by Student Name"<<endl;
        cout<<"Enter the choice"<<endl;
        cout<<choice;
        switch(choice)
        {
        case 1:
            get_data(s,2);
            break;
        case 2:
            show_data(s,2);
            break;
        case 3:
            return 0;
            break;
        default:
            cout<<"invalid";
        }
    } while(choice!=3);
    return 0;
}

