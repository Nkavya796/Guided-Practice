//tree
#include <iostream>
#include <cstring>
using namespace std;

class Node
{

	public:
	char info[50];
	Node *lchild;
	Node *rchild;
	Node(char i[20],Node *l,Node *r)
	{
		strcpy (info, i);
		lchild = l;
		rchild = r;
	}
};
class BinaryTree
{
  public:
  Node *ROOT;
  BinaryTree();
  void insert(char element[20]);
  void find(char element[20], Node **parent,Node **location);
  void inorder(Node *ptr);
  void preorder(Node *ptr);
};
BinaryTree :: BinaryTree()
{
	ROOT=NULL;
}
void BinaryTree :: insert(char element[50])
{
	Node *tmp, *parent,*currentNode;
	find(element,&parent,&currentNode);
if(currentNode!=NULL)
	{
		cout<<"\nDuplicate words not allowed";
		return;
	}
	else
	{
		tmp=new Node(element,NULL,NULL);
		if(parent==NULL)
			ROOT=tmp;
		else
			if(strcmp(element,parent->info)<0)
				parent->lchild=tmp;
			else
				parent->rchild=tmp;
	}
}
void BinaryTree :: find(char element[50],Node **parent, Node **currentNode)
{
    /* This function finds a given element in the tree and
    returns a variable containing the address of the
    corresponding node. It also returns a variable
    containing the address of the parent of the node. */
		*currentNode = ROOT;
            *parent = NULL;
            while ((*currentNode != NULL) && (strcmp((*currentNode)
            ->info,element) != 0))
            {
                *parent = *currentNode;
                if (strcmp(element,(*currentNode)->info)<0)
                    *currentNode = (*currentNode)->lchild;
                else
                    *currentNode = (*currentNode)->rchild;
            }
}


void BinaryTree :: inorder(Node *ptr)
{

	if(ptr!=NULL)
	{
		inorder(ptr->lchild);
		cout<<ptr->info<<"   ";
		inorder(ptr->rchild);
	}

}
void BinaryTree :: preorder(Node *ptr) /* Performs the preorder traversal of the tree */
{
	if(ptr!=NULL)
	{
		cout<<ptr->info<<"   ";
		preorder(ptr->lchild);
		preorder(ptr->rchild);
	}
}
int main()
{
	BinaryTree b;
//	 exit;
	char ch,word[50];
	//int num;
	do
	{
		cout<<"\nMenu";;
		cout<<"\n1. Implement insert operation"<<endl;
		cout<<"2. Perform inorder traversal"<<endl;
		cout<<"3. Perform preorder traversal"<<endl;
		cout<<"4. Exit"<<endl;
		cout<<"\nEnter your choice (1-4): ";
		cin>>ch;
		switch(ch)
		{
		case '1':
			{

				cout<<"\nEnter a word: ";
				cin>>word;
				b.insert(word);
			}
			break;
		case '2':
			{
			    if(b.ROOT==NULL)
            {

                cout<<"Tree is empty";
                return 0;
            }

				cout<<"\n";
				b.inorder(b.ROOT);
				cout<<"\n";
			}
			break;
		case '3':
			{
			    if(b.ROOT==NULL)
            {

                cout<<"Tree is empty";
                return 0;
            }

				cout<<"\n";
				b.preorder(b.ROOT);
				cout<<"\n";
			}
			break;
		case '4':

			break;
		default:
			{
				cout<<"Invalid Option."<<endl;
				break;
			}
		}
	} while(ch!='4');
	return 0;
}
