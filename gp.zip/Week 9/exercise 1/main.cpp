//linked lists
#include <iostream>

using namespace std;
class DigitEvenOdd
{
    int number,even,odd,temp;
public:
    void digitCheck()
    {
        even=0,odd=0;
        cout<<"Enter Number : ";
        cin>>number;
        while(number>0)
        {
            temp=number%10;
            if(temp%2==0)
                even++;
            else
                odd++;
            number=number/10;
        }
        cout<<even<<endl;
        cout<<odd<<endl;
        if(even%2==0 && odd%2!=0)

            cout<<"YES";
        else
            cout<<"NO";
    }
};
int main()
{
    DigitEvenOdd evenOdd;
    evenOdd.digitCheck();
    return 0;
}
