package exercise2;

class SelectionException extends Exception
{
	
	SelectionException()
	{
		System.out.println("Age invalid");
	}
	
}
