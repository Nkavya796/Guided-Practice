package com.Bankaccounts;
public class AccountsDemo {
    public static void main(String args[])
	{
		SavingAccount saccount = new SavingAccount();
		saccount.calculateInterest();
	}
    
}
