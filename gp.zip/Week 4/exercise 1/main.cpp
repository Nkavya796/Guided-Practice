//Student Management System �Part 2
 #include<iostream>
#include<string>
#include<conio.h>
#include<stdlib.h>
using namespace std;
typedef struct student
{
  int rollno;
  string name;
  string fname;
  string cell;
  string dob;
  string address;
}student;
int main();
void show_data(int searchkey);
void add_student();
void edit_student(int idnumber);
void delete1(int number);
int ts;

student rec[10];


int main()
{
char *s;
  int choice;
  int idnumber;
  int searchkey;
  cout<<"Enter The Total Number of Student(s)- Max 10: ";
  cin>>ts;

  while(ts--)
{
  cout<<"\n\t\tWhat do you want to do?"<<endl;
  cout<<"\t\t----------------------"<<endl;
  cout<<"\t\t1-Add student"<<endl;

  //cout<<"\t\t3-Search student by id"<<endl;
 cout<<"\t\t2-edit"<<endl;
 cout<<"\t\t3-delete"<<endl;
  cout<<"\t\t4-Quit Program"<<endl;
  cout<<"\t\t----------------------"<<endl;
  cout<<"Enter your choice: ";

  cin>>choice;
  switch(choice)
{
   case 1:
           add_student();
    break;



     case 2:         //If there are no records in array then it will ask the user to input records first.
    if(rec[0].rollno==0)
   {
     cout<<"Please Add students first."<<endl;
     system("pause");
    main();
   }
    else         //If records are present in array then it will show table.
   {
     cout<<endl;
     cout<<"--------------------------------------------------------------------------------"<<endl;
     cout<<"---------------------------Student record Table---------------------------------"<<endl;
     cout<<"--------------------------------------------------------------------------------"<<endl;
     cout<<"ID   "<<"Roll   "<<"Name      "<<"Father\tCell no.      "<<"DOB          "<<"Address\n\n";
     cout<<"--------------------------------------------------------------------------------"<<endl;

     for(int i=0;i<=ts;i++)
    {
      show_data(i);     //funtion is called with index value to show data.
     }

     cout<<"--------------------------------------------------------------------------------"<<endl;
     cout<<"Which ID number your want to edit: ";

     cin>>idnumber;            //Asking the user at which ID he wants to make a change.

    if(idnumber>ts || idnumber<0)  //Validating the ID number.
    {
          cout<<"\nInvalid ID Number."<<endl;
       }
       else
    {
          edit_student(idnumber);    //Passing ID number to Edit Function.
       }
   }
   break;


  case 3:
int x;
cout<<"enter rollno u want to delete";
cin>>x;
delete1(x);
break;


   case 4:
    return 0;
    break;
   default:
    cout<<"Invalid number."<<endl;
    system("pause");
  main();
  }
}
  return 0;
}


void get_data(int i)
{
  cout<<"Enter student roll number in  format(1XXX): ";
  cin>>rec[i].rollno;
  cout<<"Enter student name: ";
  cin>>rec[i].name;
  cout<<"Enter student's Father name: ";
  cin>>rec[i].fname;
  cout<<"Enter student's cell phone number: ";
  cin>>rec[i].cell;
  cout<<"Enter student's Date of Birth(dd/mm/yyyy): ";
  cin>>rec[i].dob;
  cout<<"Enter student's Address: ";
  cin>>rec[i].address;
}



void show_data(int searchkey)
{
  int i=searchkey;
  cout<<i<<"    ";
  cout<<rec[i].rollno<<"   ";
  cout<<rec[i].name<<"     ";
  cout<<rec[i].fname<<"\t";
  cout<<rec[i].cell<<"   ";
  cout<<rec[i].dob<<"   ";
  cout<<rec[i].address<<"\n\n";
}





void delete1(int n)
{
    cout<<n;
    //student details[];
  /*  int i;
int x;//variable to hold the value of the student number to delete


cout<<"show record"<<max;

//rec[max] = 0;//Mark the last record by 0. */

int i;

 int max = sizeof(rec);
for (i = 0; i < max; i++)
if (rec[i].rollno == n)
{
rec[i] = rec[i + 1];
    cout<<"record delete";
    break;
}

if (i == max)
//return -1; // The record not found.
 cout<<"record not exits";
for ( ; i < max; i++)
//rec[i] = rec[i + 1];

max--;

//return 0;

}


void edit_student(int idnumber)     //function is used to edit existing record.
{
  for(int i=0;i<=ts;i++)       //Loop is started.
{
   if(idnumber==i)       //Through loop every value is compared with search term.
  {
    cout<<"\nExisted information about this record.\n\n";
    cout<<"--------------------------------------------------------------------------------"<<endl;
    cout<<"ID   "<<"Roll   "<<"Name      "<<"Father\tCell no.      "<<"DOB          "<<"Address\n\n";
    cout<<"--------------------------------------------------------------------------------"<<endl;
    show_data(i);
    cout<<"\n\nEnter new data for above shown record.\n\n";
    get_data(i);
    cout<<"\n\nRecord updated successfully."<<endl;
    system("pause");
    main();           //Return to main function.
   }
  }
}


void add_student()         //This function is used to add record of new student.
{
  for(int i=0;i<=ts;i++)
{
    get_data(i);          //Loop was processed 5 times to get input for 5 students.
  }
  system("CLS");
  cout<<endl;
  cout<<"--------------------------------------------------------------------------------"<<endl;
  cout<<"---------------------------Student record Table---------------------------------"<<endl;
  cout<<"--------------------------------------------------------------------------------"<<endl;
  cout<<"ID   "<<"Roll   "<<"Name      "<<"Father\tCell no.      "<<"DOB          "<<"Address\n\n";
  cout<<"--------------------------------------------------------------------------------"<<endl;

  for(int i=0;i<=ts;i++)
{
    show_data(i);        //Loop was processed for 5 times to show obtained records.
  }
  cout<<"--------------------------------------------------------------------------------"<<endl;
  cout<<"---------------------------------FINISH-----------------------------------------"<<endl;
  cout<<"--------------------------------------------------------------------------------"<<endl;
  system("pause");

  main();          //Return to main function to again show menu.
}



