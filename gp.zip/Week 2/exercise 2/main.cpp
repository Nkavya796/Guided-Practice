//2 d array
#include<iostream>
#include <stdlib.h>
class employee
{
public:
int empname[5];

void acceptsname()
{
cout<<endl<<"_________________________________"<<endl;

for(int r=0;r<5;r++)
{
		cout<<"Enter the name of a employee no. "<<r+1<<"  ";
		cin>>empname[r];
}
}
void calculatenetsal(int empallow)
{

for(int r=0;r<5;r++)
{
	empsal[r]=empsal[r]+empallow;
}
}

void displaynetsal()
{
cout<<endl<<"Display Salary  Allowance  and NetSalary for all the Employees"<<endl;
cout<<endl<<"______________________________________________________________"<<endl;
cout<<endl<<"Salary  Allowance  NetSalary"<<endl;
cout<<endl<<"____________________________"<<endl;

for(int r=0;r<5;r++)
{

  cout<<empsal[r]<<endl;
}
}
};
int main(int argc, char *argv[])
{
employee object;
object.acceptempsal();
object.calculatenetsal(atoi(argv[1]));
object.displaynetsal();
}

