package com.chapter05.wood;

public abstract class Furniture
{
    protected String color;
    protected int width;
    protected int height;
    public abstract void Accept();
    public abstract void Display();
}
