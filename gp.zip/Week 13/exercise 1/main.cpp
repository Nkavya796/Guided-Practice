//quick sort
#include <iostream>
using namespace std;
#include <cstring>

class List
{
    public:

        char str[20][20];

        int cmp_count;
        int mov_count;
        int n;

        List()
        {
            cmp_count = 0;
            mov_count = 0;
        }

	void read()
	{

		while (true)
		{
			cout << "\nEnter the number of strings to be sorted: ";
			cin >> n;
			    if (n>0 && n<= 20)
                break;
            else if(n>20)
                cout<<"\nYou can enter maximum 20 strings.\n";
		}

		cout << "\n----------------------------\n";
		cout << " Enter strings (1 word each)  \n";
		cout << "------------------------------\n";


		for (int i = 0; i < n; i++)
		{
		    cout<<"Enter string "<<i+1<<": ";
			cin>>str[i];
		}
	}

		void swap(int x, int y)
     	{
               char tname[20];

               strcpy(tname, str[x]);
              strcpy(str[x], str[y]);
              strcpy(str[y], tname);

         }

        void q_sort(int low, int high)
        {
            int i, j;

            char pivot[20];
            if (low > high)
                return;


            i = low+1;
            j = high;
            strcpy(pivot,str[low]);
            while (i <= j)
            {



              while ((strcmp(pivot, str[i])>=0)&&(i <= high))

              {
                   i++;
			  cmp_count++;
              }
			  cmp_count++;


while ((strcmp(str[j],pivot)>0)&& (j >= low))

             {
                    j--;
			   cmp_count++;
              }
		    cmp_count++;

              if (i < j)
              {

                 swap(i, j);
 			 mov_count++;
                }
              }


            if (low < j)
		  {
              swap(low,j);

		    mov_count++;
            }


            q_sort(low, j - 1);
            q_sort(j + 1, high);
        }

        void display()
	   {
		cout << "\n-----------------------\n";
		cout << " Sorted strings are: \n";
		cout << "-----------------------\n";

		for (int j = 0; j < n; j++)
		{
			cout << str[j] << endl;
		}

		cout << "\nNumber of comparisons: " << cmp_count;
		cout << "\nNumber of data movements: " << mov_count;
	   }

   	   int getSize()
	   {

		return (n);

	   }
};

int main()
{

       List myList;
      myList.read();
      myList.q_sort(0, myList.getSize() - 1);
	  myList.display();
	  return 0;
}
