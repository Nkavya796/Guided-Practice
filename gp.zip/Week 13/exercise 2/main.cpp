#include <iostream>

using namespace std;

class List
{
    public:
        int arr[20];
        int cmp_count;
        int mov_count;

        int n;

        List()
        {
            cmp_count = 0;
            mov_count = 0;
        }

	void read()
	{

		while (true)
		{
			cout << "\nEnter the number of integers in the array: ";
			cin >> n;

				if (n>0 && n<= 20)
                break;
            else if(n>20)
                cout<<"\nArray can have maximum 20 integers.\n";
            else if (n < 0)
                cout<<"\nEnter positive number.\n";




		}

		cout << "\n-----------------------\n";
		cout << " Enter integers  \n";
		cout << "-----------------------\n";


		for (int i = 0; i < n; i++)
		{
			cout << "<" << (i + 1) << "> ";
			cin >> arr[i];
		}
	}

		void swap(int x, int y)

     		{
            int temp;
            temp = arr[x];
       arr[x] = arr[y];
 	arr[y] = temp;
         }

        void q_sort(int low, int high)
        {
            int pivot, i, j;
            if (low > high)
                return;


            i = low+1;
            j = high;
            pivot = arr[low];
            while (i <= j)
            {

                while ((arr[i] <= pivot) && (i <= high))
                {
                    i++;
					cmp_count++;
                }
				cmp_count++;



                while ((arr[j] > pivot) && (j >= low))
                {
                    j--;
					cmp_count++;
                }
		    cmp_count++;

                if (i < j)

                {

                    swap(i, j);
 			 mov_count++;
                }
            }


            if (low < j)
		{
                swap(low,j);
		    mov_count++;
            }


            q_sort(low, j - 1);


            q_sort(j + 1, high);
        }

        void display()
	   {
		cout << "\n-----------------------\n";
		cout << " Sorted array \n";
		cout << "-----------------------\n";

		for (int j = 0; j < n; j++)
		{
			cout << arr[j] << endl;
		}

		cout << "\nNumber of comparisons: " << cmp_count;
		cout << "\nNumber of data movements: " << mov_count;
	   }

   	   int getSize()
	   {
		return (n);
	   }
};

int main()
{

        List myList;


	   myList.read();


        myList.q_sort(0, myList.getSize() - 1);


	   myList.display();
	   return 0;
}
